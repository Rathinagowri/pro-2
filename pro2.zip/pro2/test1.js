
 describe("Check",function(){
	
it("check value of variable", function() {
    var a = "hello world";
    expect(a).toEqual("helloworld");
  });

})
